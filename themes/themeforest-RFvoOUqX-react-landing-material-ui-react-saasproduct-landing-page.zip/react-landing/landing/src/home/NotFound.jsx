import React from "react";

const NotFound = props => {
  return <h1>404</h1>;
};

export default NotFound;
