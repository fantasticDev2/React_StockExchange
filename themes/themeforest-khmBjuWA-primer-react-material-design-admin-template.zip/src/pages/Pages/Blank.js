import React from 'react';
import { Wrapper } from '../../components';

const Blank = () => (
  <Wrapper>
    <p>Blank</p>
  </Wrapper>
);

export default Blank;
